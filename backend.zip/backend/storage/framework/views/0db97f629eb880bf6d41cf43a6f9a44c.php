<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Message de <?php echo e($contact->name); ?> <?php $__env->endSlot(); ?>

    <div class="max-w-3xl">
        <div class="bg-white rounded-xl shadow-sm p-8">
            <div class="flex items-start justify-between mb-8 pb-6 border-b">
                <div>
                    <h3 class="text-xl font-bold text-gray-800"><?php echo e($contact->name); ?></h3>
                    <a href="mailto:<?php echo e($contact->email); ?>"
                        class="text-blue-600 hover:underline"><?php echo e($contact->email); ?></a>
                </div>
                <div class="text-right text-gray-500">
                    <p><?php echo e($contact->created_at->format('d/m/Y à H:i')); ?></p>
                    <p class="text-sm"><?php echo e($contact->created_at->diffForHumans()); ?></p>
                </div>
            </div>

            <?php if($contact->subject): ?>
                <div class="mb-4">
                    <h4 class="text-sm font-semibold text-gray-500 mb-1">Sujet</h4>
                    <p class="text-gray-800"><?php echo e($contact->subject); ?></p>
                </div>
            <?php endif; ?>

            <div class="mb-8">
                <h4 class="text-sm font-semibold text-gray-500 mb-2">Message</h4>
                <div class="bg-gray-50 rounded-lg p-6">
                    <p class="text-gray-700 whitespace-pre-wrap"><?php echo e($contact->message); ?></p>
                </div>
            </div>

            <div class="flex gap-4 pt-6 border-t">
                <a href="mailto:<?php echo e($contact->email); ?>"
                    class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                    ✉️ Répondre par email
                </a>
                <a href="<?php echo e(route('admin.contacts.index')); ?>"
                    class="px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition">
                    Retour à la liste
                </a>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH /Users/fvfl73g71wfv/Documents/Portfolio maxime/backend/resources/views/admin/contacts/show.blade.php ENDPATH**/ ?>