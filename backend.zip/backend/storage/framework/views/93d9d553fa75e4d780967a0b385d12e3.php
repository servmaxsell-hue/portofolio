<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Messages <?php $__env->endSlot(); ?>

    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-gray-600">Expéditeur</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-gray-600">Message</th>
                    <th class="px-6 py-4 text-center text-sm font-semibold text-gray-600">Statut</th>
                    <th class="px-6 py-4 text-right text-sm font-semibold text-gray-600">Date</th>
                    <th class="px-6 py-4 text-right text-sm font-semibold text-gray-600">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50 <?php echo e(!$contact->read ? 'bg-blue-50' : ''); ?>">
                        <td class="px-6 py-4">
                            <p class="font-semibold <?php echo e(!$contact->read ? 'text-blue-600' : 'text-gray-800'); ?>">
                                <?php echo e($contact->name); ?></p>
                            <p class="text-sm text-gray-500"><?php echo e($contact->email); ?></p>
                        </td>
                        <td class="px-6 py-4">
                            <p class="text-gray-600 truncate max-w-md"><?php echo e($contact->message); ?></p>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <?php if($contact->read): ?>
                                <span class="px-3 py-1 text-xs font-medium bg-gray-100 text-gray-500 rounded-full">Lu</span>
                            <?php else: ?>
                                <span
                                    class="px-3 py-1 text-xs font-medium bg-blue-100 text-blue-700 rounded-full">Nouveau</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-right text-gray-500 text-sm">
                            <?php echo e($contact->created_at->diffForHumans()); ?>

                        </td>
                        <td class="px-6 py-4 text-right">
                            <a href="<?php echo e(route('admin.contacts.show', $contact)); ?>"
                                class="text-blue-600 hover:underline mr-3">Voir</a>
                            <form action="<?php echo e(route('admin.contacts.destroy', $contact)); ?>" method="POST" class="inline"
                                onsubmit="return confirm('Supprimer ce message ?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center text-gray-500">
                            Aucun message reçu pour le moment.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        <?php echo e($contacts->links()); ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH /Users/fvfl73g71wfv/Documents/Portfolio maxime/backend/resources/views/admin/contacts/index.blade.php ENDPATH**/ ?>