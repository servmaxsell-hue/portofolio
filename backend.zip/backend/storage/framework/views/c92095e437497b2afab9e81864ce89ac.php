<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Articles <?php $__env->endSlot(); ?>
     <?php $__env->slot('actions', null, []); ?> 
        <a href="<?php echo e(route('admin.articles.create')); ?>"
            class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
            + Nouvel article
        </a>
     <?php $__env->endSlot(); ?>

    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-gray-600">Titre</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-gray-600">Tags</th>
                    <th class="px-6 py-4 text-center text-sm font-semibold text-gray-600">Statut</th>
                    <th class="px-6 py-4 text-center text-sm font-semibold text-gray-600">Lecture</th>
                    <th class="px-6 py-4 text-right text-sm font-semibold text-gray-600">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4">
                            <p class="font-semibold text-gray-800"><?php echo e($article->title); ?></p>
                            <p class="text-sm text-gray-500"><?php echo e(Str::limit($article->excerpt, 50)); ?></p>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex flex-wrap gap-1">
                                <?php $__currentLoopData = array_slice($article->tags ?? [], 0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="px-2 py-1 text-xs bg-purple-100 text-purple-700 rounded"><?php echo e($tag); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <?php if($article->published): ?>
                                <span
                                    class="px-3 py-1 text-xs font-medium bg-green-100 text-green-700 rounded-full">Publié</span>
                            <?php else: ?>
                                <span
                                    class="px-3 py-1 text-xs font-medium bg-yellow-100 text-yellow-700 rounded-full">Brouillon</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-center text-gray-500">
                            <?php echo e($article->read_time); ?> min
                        </td>
                        <td class="px-6 py-4 text-right">
                            <a href="<?php echo e(route('admin.articles.edit', $article)); ?>"
                                class="text-blue-600 hover:underline mr-3">Modifier</a>
                            <form action="<?php echo e(route('admin.articles.destroy', $article)); ?>" method="POST" class="inline"
                                onsubmit="return confirm('Supprimer cet article ?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center text-gray-500">
                            Aucun article. <a href="<?php echo e(route('admin.articles.create')); ?>"
                                class="text-blue-600 hover:underline">Créer le premier</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        <?php echo e($articles->links()); ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH /Users/fvfl73g71wfv/Documents/Portfolio maxime/backend/resources/views/admin/articles/index.blade.php ENDPATH**/ ?>